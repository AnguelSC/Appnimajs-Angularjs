App42_PHP_SDK
=============

App42 Cloud API Client SDK files for PHP

[Download the latest App42 PHP SDK] (https://github.com/shephertz/App42_PHP_SDK/raw/master/1.0/app42_php_1.0.zip)

[Documentation and API guide] (http://api.shephertz.com/cloudapidocs/index.php)

[SIGN UP] (https://apphq.shephertz.com/register)

On the success of registration you will receieve the API KEY and SECRET KEYs for dummy application created for quick start. Intention of dummy application is to makeuser experience seamless to use the APIs.

Download the SDK and Unzip the file which contains the Sample App and API Docs

How to use PHP SDK :

Copy the SampleApp.php into App42_PHP_SDK_x.x.x Folder



NOTE : You have to open curl settings in php.ini file

Steps: 

1. Open php.ini and search with keyword "curl" 

2. remove ";" before "extension=php_curl.dll"

3. restart your xampp panel.

4. ready to use.
