* [Release Version 1.9](https://github.com/shephertz/App42_JAVASCRIPT_SDK/blob/master/Change%20Log.md#version-19)
* [Release Version 1.8](https://github.com/shephertz/App42_JAVASCRIPT_SDK/blob/master/Change%20Log.md#version-18)

## Version 1.9

**Release Date:** 22-10-2013

**Release Version:** 1.9

**The following Service have been pushed to the latest :**

```
AB Test Service
```

**This release contains the following bug fix:**

```
None
```


## Version 1.8

**Release Date:** 23-09-2013

**Release Version:** 1.8

**The following Service have been pushed to the latest :**

```
Avatar Service
Achievement Service
```

**The following features have been pushed to the Social Service :**

```
facebookPublishStream
facebookLinkPost
facebookLinkPostWithCustomThumbnail
getFacebookProfile
```

**This release contains the following bug fix:**

```
None
```
